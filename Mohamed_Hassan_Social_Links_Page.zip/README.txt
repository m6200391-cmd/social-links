HOW TO PUBLISH
1. Upload index.html to any static web host (GitHub Pages is a free option).
2. Copy the public page URL.
3. Generate a new QR code using that URL.
4. Print the QR code on the car sticker.

IMPORTANT:
The included QR_CODE_AFTER_HOSTING.png is only a placeholder because the final QR must contain the public URL of your hosted page.
